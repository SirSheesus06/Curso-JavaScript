// Exportar 2 funciones: suma y multiplica

export function suma(a = 0, b = 0) {
    return a + b;
}

export function multiplica(a = 0, b = 0) {
    return a * b;
}